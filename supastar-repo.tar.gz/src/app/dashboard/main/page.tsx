import Dashboard from './_PageSections/Dashboard';

export default async function DashboardPage() {
  return (
    <div>
      <Dashboard />
    </div>
  );
}
