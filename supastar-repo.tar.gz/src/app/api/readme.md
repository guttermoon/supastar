unlike the older pages router. /api has no special meaning in app router. A route is instead created by naming a file route.ts.

/api is only used for logically organizing /api requests using the special route handler file.
