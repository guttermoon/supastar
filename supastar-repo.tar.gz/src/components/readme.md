Basic building blocks of Pages are placed here.

Basic components can be placed in /ui.

More complex components that are shared across multiple pages can be placed in /components

complex components that are only used by a single page, should just be placed in that specific pages /\_PageSections directory.
