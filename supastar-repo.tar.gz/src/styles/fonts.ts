import { Inter } from 'next/font/google';

export const InterFont = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter'
});
