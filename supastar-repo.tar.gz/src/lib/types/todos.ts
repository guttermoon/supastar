export type TodoT = {
  id?: string;
  title: string;
  description: string;
  author?: string;
  user_id?: string;
};
