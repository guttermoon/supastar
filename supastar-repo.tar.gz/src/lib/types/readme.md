This directory contains types, emums and form validations.
