export enum IntervalE {
  MONTHLY = 'Monthly',
  YEARLY = 'Yearly'
}
