const config = {
  errorMessageGeneral: 'Something Went Wrong',
  swrKeys: {
    getMyTodos: 'GetMyTodos',
    getAllTodos: 'GetAllTodos'
  }
};

export default config;
